var novoArrayMovies = []

novoArrayMovies.push(filme("The Incredible Hulk",
                           2008,
                           "https://m.media-amazon.com/images/M/MV5BMTUyNzk3MjA1OF5BMl5BanBnXkFtZTcwMTE1Njg2MQ@@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2011,
                           "https://www.imdb.com/title/tt0800080/?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Iron Man",
                           2008,
                           "https://m.media-amazon.com/images/M/MV5BMTczNTI2ODUwOF5BMl5BanBnXkFtZTcwMTU0NTIzMw@@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2010,
                           "https://www.imdb.com/title/tt0371746/?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Iron Man 2",
                           2010,
                           "https://m.media-amazon.com/images/M/MV5BMTM0MDgwNjMyMl5BMl5BanBnXkFtZTcwNTg3NzAzMw@@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2011,
                           "https://www.imdb.com/title/tt1228705?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Iron Man 3",
                           2013,
                           "https://m.media-amazon.com/images/M/MV5BMjE5MzcyNjk1M15BMl5BanBnXkFtZTcwMjQ4MjcxOQ@@._V1_UY268_CR3,0,182,268_AL_.jpg",
                           2012,
                           "https://www.imdb.com/title/tt1300854?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Thor",
                           2011,
                           "https://m.media-amazon.com/images/M/MV5BOGE4NzU1YTAtNzA3Mi00ZTA2LTg2YmYtMDJmMThiMjlkYjg2XkEyXkFqcGdeQXVyNTgzMDMzMTg@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2011,
                           "https://www.imdb.com/title/tt0800369?ref_=nv_sr_srsg_6"))

novoArrayMovies.push(filme("Thor: The Dark World",
                           2013,
                           "https://m.media-amazon.com/images/M/MV5BMTQyNzAwOTUxOF5BMl5BanBnXkFtZTcwMTE0OTc5OQ@@._V1_UY268_CR3,0,182,268_AL_.jpg",
                           2013,
                           "https://www.imdb.com/title/tt1981115?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Thor: Ragnarok",
                           2017,
                           "https://m.media-amazon.com/images/M/MV5BMjMyNDkzMzI1OF5BMl5BanBnXkFtZTgwODcxODg5MjI@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2017,
                           "https://www.imdb.com/title/tt3501632?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Captain America: The First Avenger",
                           2011,
                           "https://m.media-amazon.com/images/M/MV5BMTYzOTc2NzU3N15BMl5BanBnXkFtZTcwNjY3MDE3NQ@@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           1943,
                           "https://www.imdb.com/title/tt0458339/?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Captain America: The Winter Soldier",
                           2014,
                           "https://m.media-amazon.com/images/M/MV5BMzA2NDkwODAwM15BMl5BanBnXkFtZTgwODk5MTgzMTE@._V1_UY268_CR1,0,182,268_AL_.jpg",
                           2014,
                           "https://www.imdb.com/title/tt1843866?ref_=nv_sr_srsg_3"))

novoArrayMovies.push(filme("Captain America: Civil War",
                           2016,
                           "https://m.media-amazon.com/images/M/MV5BMjQ0MTgyNjAxMV5BMl5BanBnXkFtZTgwNjUzMDkyODE@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2016,
                           "https://www.imdb.com/title/tt3498820?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Guardians of the Galaxy",
                           2014,
                           "https://m.media-amazon.com/images/M/MV5BMTAwMjU5OTgxNjZeQTJeQWpwZ15BbWU4MDUxNDYxODEx._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2014,
                           "https://www.imdb.com/title/tt2015381?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Guardians of the Galaxy 2",
                           2017,
                           "https://m.media-amazon.com/images/M/MV5BNjM0NTc0NzItM2FlYS00YzEwLWE0YmUtNTA2ZWIzODc2OTgxXkEyXkFqcGdeQXVyNTgwNzIyNzg@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2014,
                           "https://www.imdb.com/title/tt3896198?ref_=nv_sr_srsg_3"))

novoArrayMovies.push(filme("Doctor Strange",
                           2016,
                           "https://m.media-amazon.com/images/M/MV5BNjgwNzAzNjk1Nl5BMl5BanBnXkFtZTgwMzQ2NjI1OTE@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2016,
                           "https://www.imdb.com/title/tt1211837?ref_=nv_sr_srsg_3"))

novoArrayMovies.push(filme("Ant-Man",
                           2015,
                           "https://m.media-amazon.com/images/M/MV5BMjM2NTQ5Mzc2M15BMl5BanBnXkFtZTgwNTcxMDI2NTE@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2015,
                           "https://www.imdb.com/title/tt0478970?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Ant-Man and the Wasp",
                           2018,
                           "https://m.media-amazon.com/images/M/MV5BYjcyYTk0N2YtMzc4ZC00Y2E0LWFkNDgtNjE1MzZmMGE1YjY1XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2017,
                           "https://www.imdb.com/title/tt5095030?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Black Panther",
                           2018,
                           "https://m.media-amazon.com/images/M/MV5BMTg1MTY2MjYzNV5BMl5BanBnXkFtZTgwMTc4NTMwNDI@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2017,
                           "https://www.imdb.com/title/tt1825683?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Captain Marvel",
                           2019,
                           "https://m.media-amazon.com/images/M/MV5BMTE0YWFmOTMtYTU2ZS00ZTIxLWE3OTEtYTNiYzBkZjViZThiXkEyXkFqcGdeQXVyODMzMzQ4OTI@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           1995,
                           "https://www.imdb.com/title/tt4154664?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Spider-Man: Homecoming",
                           2017,
                           "https://m.media-amazon.com/images/M/MV5BNTk4ODQ1MzgzNl5BMl5BanBnXkFtZTgwMTMyMzM4MTI@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2016,
                           "https://www.imdb.com/title/tt2250912?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Spider-Man: Far from Home",
                           2019.2,
                           "https://m.media-amazon.com/images/M/MV5BMGZlNTY1ZWUtYTMzNC00ZjUyLWE0MjQtMTMxN2E3ODYxMWVmXkEyXkFqcGdeQXVyMDM2NDM2MQ@@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2024,
                           "https://www.imdb.com/title/tt6320628?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("The Avengers",
                           2012,
                           "https://m.media-amazon.com/images/M/MV5BNDYxNjQyMjAtNTdiOS00NGYwLWFmNTAtNThmYjU5ZGI2YTI1XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2012,
                           "https://www.imdb.com/title/tt0848228?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Avengers: Age of Ultron",
                           2015,
                           "https://m.media-amazon.com/images/M/MV5BMTM4OGJmNWMtOTM4Ni00NTE3LTg3MDItZmQxYjc4N2JhNmUxXkEyXkFqcGdeQXVyNTgzMDMzMTg@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2015,
                           "https://www.imdb.com/title/tt2395427?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Avengers: Infinity War",
                           2018,
                           "https://m.media-amazon.com/images/M/MV5BMjMxNjY2MDU1OV5BMl5BanBnXkFtZTgwNzY1MTUwNTM@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2017,
                           "https://www.imdb.com/title/tt4154756?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Avengers: End Game",
                           2019.1,
                           "https://m.media-amazon.com/images/M/MV5BMTc5MDE2ODcwNV5BMl5BanBnXkFtZTgwMzI2NzQ2NzM@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2018,
                           "https://www.imdb.com/title/tt4154796?ref_=nv_sr_srsg_0"))

novoArrayMovies.push(filme("Spider-Man: No Way Home",
                           2021,
                           "https://m.media-amazon.com/images/M/MV5BNTMxOGI4OGMtMTgwMy00NmFjLWIyOTUtYjQ0OGQ4Mjk0YjNjXkEyXkFqcGdeQXVyMDM2NDM2MQ@@._V1_UX182_CR0,0,182,268_AL_.jpg",
                           2024,
                           "https://www.imdb.com/title/tt10872600/?ref_=nv_sr_srsg_0"))

ordenar()
imprime()

function ordenar() {
  var ordem = parseInt(document.getElementById("ordenarFilmes").value)

  if (ordem == 3) {
    arraySort(novoArrayMovies, 1)
  }

  arraySort(novoArrayMovies, ordem)
  imprime()
}

function imprime() {
  var montaDiv, anoImpresso, filtro
  var ordem = parseInt(document.getElementById("ordenarFilmes").value)

  var div = document.querySelector('.container-total') //Mapeia o HTML em busca de um elemento com a classe '.container-total'
  div.innerHTML = ""

  filtro = ordem == 3 ? "Cronologia: " : "Lançamento: "

  for (var x = 0; x < novoArrayMovies.length; x++) {
    let tagH2 = document.createElement('h2')
    let tagA = document.createElement('a')
    let tagImage = document.createElement('img')
    let tagDivFilme = document.createElement('div') //Cria um elemento '<div>'

    tagH2.innerHTML = novoArrayMovies[x].nome + "<br>" + filtro + parseInt(ordem == 3 ? novoArrayMovies[x].anoCronologico : novoArrayMovies[x].anoLancamento)
    tagA.href = novoArrayMovies[x].linkPagina
    tagA.target = "_blank"
    tagImage.src = novoArrayMovies[x].linkImagem
    tagImage.alt = novoArrayMovies[x].nome
    tagDivFilme.classList.add('container-movies') //Adiciono uma classe ao elemento
    tagA.appendChild(tagImage)
    tagDivFilme.appendChild(tagH2)
    tagDivFilme.appendChild(tagA)
    div.appendChild(tagDivFilme) // Adiciono a div filme dentro da div principal
  }
}

function filme(nomeFilme, anoLanc, imagem, anoCron, linkPag) {
  var filme = {
    nome: nomeFilme,
    anoLancamento: anoLanc,
    linkImagem: imagem,
    anoCronologico: anoCron,
    linkPagina: linkPag
  }

  return filme;
}

function arraySort(vet, x) {
  vet.sort(function compare(a, b) {
    switch (x) {
      case 0:
        return a.nome < b.nome ? -1 : a.nome > b.nome ? 1 : 0
        break
      case 1:
        return a.anoLancamento < b.anoLancamento ? -1 : a.anoLancamento > b.anoLancamento ? 1 : 0
        break
      default:
        return a.anoCronologico < b.anoCronologico ? -1 : a.anoCronologico > b.anoCronologico ? 1 : 0
    }
  })

  return vet
}

/*
function arraySort(vet, x) {
  vet.sort(function compare(a, b) {
    return a.[x] < b.[x] ? -1 : a.[x] > b.[x] ? 1 : 0
  })

  return vet
}
*/